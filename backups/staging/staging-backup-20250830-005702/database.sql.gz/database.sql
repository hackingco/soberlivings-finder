--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4 (Debian 15.4-1.pgdg110+1)
-- Dumped by pg_dump version 15.4 (Debian 15.4-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: audit; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA audit;


ALTER SCHEMA audit OWNER TO postgres;

--
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gin WITH SCHEMA public;


--
-- Name: EXTENSION btree_gin; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gin IS 'support for indexing common datatypes in GIN';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    "userId" text,
    action text NOT NULL,
    "entityType" text NOT NULL,
    "entityId" text NOT NULL,
    changes jsonb,
    metadata jsonb,
    "ipAddress" text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: availability_updates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.availability_updates (
    id text NOT NULL,
    "facilityId" text NOT NULL,
    "availableBeds" integer NOT NULL,
    "totalBeds" integer NOT NULL,
    "waitlistCount" integer DEFAULT 0 NOT NULL,
    "lastConfirmed" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    notes text,
    "submittedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.availability_updates OWNER TO postgres;

--
-- Name: facilities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.facilities (
    id text NOT NULL,
    name text NOT NULL,
    city text NOT NULL,
    state text NOT NULL,
    zip text,
    phone text,
    website text,
    latitude double precision,
    longitude double precision,
    "acceptedInsurance" text[],
    "allServices" text,
    amenities text[],
    capacity integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    description text,
    "lastUpdated" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    programs text[],
    "residentialServices" text,
    street text,
    verified boolean DEFAULT false NOT NULL,
    services text[]
);


ALTER TABLE public.facilities OWNER TO postgres;

--
-- Name: operators; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.operators (
    id text NOT NULL,
    "facilityId" text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    role text,
    "kycVerified" boolean DEFAULT false NOT NULL,
    "kycDocuments" jsonb,
    "approvedAt" timestamp(3) without time zone,
    "approvedBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.operators OWNER TO postgres;

--
-- Name: verification_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.verification_requests (
    id text NOT NULL,
    "facilityId" text NOT NULL,
    "operatorId" text,
    "requestType" text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    documents jsonb,
    notes text,
    "reviewedBy" text,
    "reviewedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.verification_requests OWNER TO postgres;

--
-- Name: webhook_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.webhook_events (
    id text NOT NULL,
    url text NOT NULL,
    method text NOT NULL,
    headers jsonb,
    payload jsonb NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    "lastAttemptAt" timestamp(3) without time zone,
    "responseStatus" integer,
    "responseBody" text,
    error text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.webhook_events OWNER TO postgres;

--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (id, "userId", action, "entityType", "entityId", changes, metadata, "ipAddress", "userAgent", "createdAt") FROM stdin;
cmextqoa5000np11jdz7u7988	admin	facility.create	facility	cmextqn430005p11jjbghmm6e	{"name": "Serenity House"}	{"source": "seed"}	127.0.0.1	seed-script	2025-08-30 05:31:40.013
\.


--
-- Data for Name: availability_updates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.availability_updates (id, "facilityId", "availableBeds", "totalBeds", "waitlistCount", "lastConfirmed", notes, "submittedBy", "createdAt") FROM stdin;
cmextqo9z000lp11j98zbs2jm	cmextqn430005p11jjbghmm6e	10	50	5	2025-08-30 05:31:40.007	Updated availability	cmextqo72000cp11j7biokd92	2025-08-30 05:31:40.007
cmextqo9z000kp11jlpfpeiyg	cmextqn470008p11jy8k0yjtb	25	100	0	2025-08-30 05:31:40.007	Plenty of space available	\N	2025-08-30 05:31:40.007
\.


--
-- Data for Name: facilities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.facilities (id, name, city, state, zip, phone, website, latitude, longitude, "acceptedInsurance", "allServices", amenities, capacity, "createdAt", description, "lastUpdated", programs, "residentialServices", street, verified, services) FROM stdin;
cmextqmg00000p11jm8mxz7r9	Santa Barbara Healing	Santa Barbara	CA	93101	(805) 555-0800	https://sbhealing.example.com	34.4208	-119.6982	{"PPO Plans",Out-of-Network}	Holistic, Alternative therapies	{yoga_studio,acupuncture,nutrition_counseling}	20	2025-08-30 05:31:37.632	Alternative and holistic treatment approaches	2025-08-30 05:31:37.632	{mindfulness,meditation,nutrition}	Holistic Treatment	369 State Street	t	{residential,holistic}
cmextqmvr0004p11jo1lh89yg	Malibu Shores Recovery	Malibu	CA	90265	(310) 555-0500	https://malibushores.example.com	34.0259	-118.7798	{"Private Pay","Premium Insurance"}	Luxury treatment, Spa services	{spa,private_rooms,chef,beach_access}	15	2025-08-30 05:31:37.632	Premium beachfront recovery facility	2025-08-30 05:31:37.632	{executive,professionals}	Luxury Residential	654 Pacific Coast Highway	t	{residential,luxury}
cmextqmvq0002p11jvzrdoxo7	Sacramento Valley Recovery	Sacramento	CA	95814	(916) 555-0300	https://sacvalleyrecovery.example.com	38.5816	-121.4944	{Kaiser,Anthem,"Private Pay"}	Long-term care, Sober living	{hiking_trails,art_therapy,music_room}	30	2025-08-30 05:31:37.632	Long-term recovery in the Colorado mountains	2025-08-30 05:31:37.632	{wilderness-therapy,equine-therapy}	Long-term Residential	789 Capitol Avenue	f	{residential,sober_living}
cmextqmvp0001p11jk9gfmlv7	Pasadena Youth Academy	Pasadena	CA	91101	(626) 555-1000	https://pasadenayouth.example.com	34.1478	-118.1445	{"School Insurance","Parent PPO"}	Teen programs, Family therapy	{classroom,sports_facilities,family_rooms}	25	2025-08-30 05:31:37.632	Specialized treatment for teens and young adults	2025-08-30 05:31:37.632	{academic-support,family-therapy,teen-groups}	Adolescent Treatment	159 Colorado Boulevard	t	{residential,adolescent}
cmextqmvq0003p11je8ckdbsu	Veterans Recovery House	San Diego	CA	92101	(619) 555-0900	\N	32.7157	-117.1611	{"VA Benefits",Tricare}	Veterans-specific treatment	{fitness_center,counseling_rooms,group_spaces}	35	2025-08-30 05:31:37.632	Specialized treatment for military veterans	2025-08-30 05:31:37.632	{PTSD-treatment,combat-trauma,veteran-peer-support}	Veterans Program	777 Honor Drive	t	{residential,veterans}
cmextqn470008p11jy8k0yjtb	Hope Recovery Center	Los Angeles	CA	90001	(213) 555-0200	https://hoperecovery.example.com	34.0522	-118.2437	{Cigna,"United Healthcare",Medicaid}	IOP, PHP, Counseling	{cafeteria,library,outdoor_space}	100	2025-08-30 05:31:37.632	Comprehensive outpatient treatment in Los Angeles	2025-08-30 05:31:37.632	{CBT,DBT,group-therapy}	Intensive Outpatient	456 Wellness Blvd	t	{outpatient,counseling}
cmextqn470007p11jvpf9hs3l	Oakland New Beginnings	Oakland	CA	94607	(510) 555-0700	\N	37.8044	-122.2712	{"Sliding Scale","Grant Funded"}	Sober living, Life skills training	{job_placement,life_skills_classes}	25	2025-08-30 05:31:37.632	Transitional sober living with life skills training	2025-08-30 05:31:37.632	{vocational-training,peer-support}	Transitional Living	246 Broadway	f	{sober_living,transitional}
cmextqn430005p11jjbghmm6e	Serenity House	San Francisco	CA	94102	(415) 555-0100	https://serenityhouse.example.com	37.7749	-122.4194	{Aetna,"Blue Cross",Medicare}	Residential, Outpatient, Detox	{gym,pool,meditation_room}	50	2025-08-30 05:31:37.632	A peaceful recovery center in the heart of San Francisco	2025-08-30 05:31:37.632	{12-step,holistic,dual-diagnosis}	Residential Treatment	123 Recovery Lane	t	{residential,outpatient,detox}
cmextqn480009p11jn0o6brga	Fresno Valley Hope	Fresno	CA	93704	(559) 555-0600	\N	36.7378	-119.7871	{Medicare,Medicaid,"State Insurance"}	Residential, Aftercare	{recreation_room,computer_lab}	40	2025-08-30 05:31:37.632	Affordable treatment with strong aftercare program	2025-08-30 05:31:37.632	{12-step,relapse-prevention}	Standard Residential	987 Shaw Avenue	t	{residential,aftercare}
cmextqn440006p11jrss6e7rr	Orange County Wellness	Newport Beach	CA	92663	(949) 555-0400	\N	33.6189	-117.9289	{BCBS,Humana}	Detox, Stabilization	{24hr_nursing,pharmacy}	20	2025-08-30 05:31:37.632	Medical detoxification and stabilization services	2025-08-30 05:31:37.632	{medical-detox,medication-assisted}	Medical Detox	321 Newport Boulevard	t	{detox,medical}
\.


--
-- Data for Name: operators; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.operators (id, "facilityId", name, email, phone, role, "kycVerified", "kycDocuments", "approvedAt", "approvedBy", "createdAt", "updatedAt") FROM stdin;
cmextqo72000dp11jn0s5mwse	cmextqn470008p11jy8k0yjtb	Jane Doe	jane@hoperecovery.com	(213) 555-0201	manager	f	\N	\N	\N	2025-08-30 05:31:39.903	2025-08-30 05:31:39.903
cmextqo72000cp11j7biokd92	cmextqn430005p11jjbghmm6e	John Smith	john@serenityhouse.com	(415) 555-0101	owner	t	{"type": "license", "number": "CA12345"}	2025-08-30 05:31:39.901	admin	2025-08-30 05:31:39.903	2025-08-30 05:31:39.903
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: verification_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.verification_requests (id, "facilityId", "operatorId", "requestType", status, documents, notes, "reviewedBy", "reviewedAt", "createdAt", "updatedAt") FROM stdin;
cmextqo9s000hp11j7ybgvjwt	cmextqn430005p11jjbghmm6e	cmextqo72000cp11j7biokd92	information_update	approved	{"file": "update.pdf", "type": "update"}	Information update approved	admin	2025-08-30 05:31:40	2025-08-30 05:31:40	2025-08-30 05:31:40
cmextqo9s000gp11jo2tv1aqg	cmextqmvq0002p11jvzrdoxo7	\N	ownership	pending	{"file": "deed.pdf", "type": "deed"}	Pending ownership verification	\N	\N	2025-08-30 05:31:40	2025-08-30 05:31:40
\.


--
-- Data for Name: webhook_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.webhook_events (id, url, method, headers, payload, status, attempts, "lastAttemptAt", "responseStatus", "responseBody", error, "createdAt", "updatedAt") FROM stdin;
cmextqoa2000mp11jc6yx3byw	https://example.com/webhook	POST	{"Content-Type": "application/json"}	{"event": "facility.created", "facilityId": "cmextqn430005p11jjbghmm6e"}	pending	0	\N	\N	\N	\N	2025-08-30 05:31:40.011	2025-08-30 05:31:40.011
\.


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: availability_updates availability_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.availability_updates
    ADD CONSTRAINT availability_updates_pkey PRIMARY KEY (id);


--
-- Name: facilities facilities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.facilities
    ADD CONSTRAINT facilities_pkey PRIMARY KEY (id);


--
-- Name: operators operators_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operators
    ADD CONSTRAINT operators_pkey PRIMARY KEY (id);


--
-- Name: verification_requests verification_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_requests
    ADD CONSTRAINT verification_requests_pkey PRIMARY KEY (id);


--
-- Name: webhook_events webhook_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "audit_logs_createdAt_idx" ON public.audit_logs USING btree ("createdAt");


--
-- Name: audit_logs_entityType_entityId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "audit_logs_entityType_entityId_idx" ON public.audit_logs USING btree ("entityType", "entityId");


--
-- Name: audit_logs_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "audit_logs_userId_idx" ON public.audit_logs USING btree ("userId");


--
-- Name: availability_updates_facilityId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "availability_updates_facilityId_idx" ON public.availability_updates USING btree ("facilityId");


--
-- Name: availability_updates_lastConfirmed_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "availability_updates_lastConfirmed_idx" ON public.availability_updates USING btree ("lastConfirmed");


--
-- Name: facilities_latitude_longitude_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX facilities_latitude_longitude_idx ON public.facilities USING btree (latitude, longitude);


--
-- Name: facilities_state_city_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX facilities_state_city_idx ON public.facilities USING btree (state, city);


--
-- Name: facilities_verified_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX facilities_verified_idx ON public.facilities USING btree (verified);


--
-- Name: idx_facilities_location; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_facilities_location ON public.facilities USING gist (public.st_makepoint(longitude, latitude));


--
-- Name: idx_facilities_name_search; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_facilities_name_search ON public.facilities USING gin (to_tsvector('english'::regconfig, name));


--
-- Name: operators_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX operators_email_idx ON public.operators USING btree (email);


--
-- Name: operators_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX operators_email_key ON public.operators USING btree (email);


--
-- Name: operators_facilityId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "operators_facilityId_idx" ON public.operators USING btree ("facilityId");


--
-- Name: operators_kycVerified_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "operators_kycVerified_idx" ON public.operators USING btree ("kycVerified");


--
-- Name: verification_requests_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "verification_requests_createdAt_idx" ON public.verification_requests USING btree ("createdAt");


--
-- Name: verification_requests_facilityId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "verification_requests_facilityId_idx" ON public.verification_requests USING btree ("facilityId");


--
-- Name: verification_requests_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX verification_requests_status_idx ON public.verification_requests USING btree (status);


--
-- Name: webhook_events_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "webhook_events_createdAt_idx" ON public.webhook_events USING btree ("createdAt");


--
-- Name: webhook_events_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX webhook_events_status_idx ON public.webhook_events USING btree (status);


--
-- Name: availability_updates availability_updates_facilityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.availability_updates
    ADD CONSTRAINT "availability_updates_facilityId_fkey" FOREIGN KEY ("facilityId") REFERENCES public.facilities(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: operators operators_facilityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operators
    ADD CONSTRAINT "operators_facilityId_fkey" FOREIGN KEY ("facilityId") REFERENCES public.facilities(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: verification_requests verification_requests_facilityId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.verification_requests
    ADD CONSTRAINT "verification_requests_facilityId_fkey" FOREIGN KEY ("facilityId") REFERENCES public.facilities(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

